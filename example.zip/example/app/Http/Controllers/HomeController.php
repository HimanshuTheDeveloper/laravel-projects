<?php

namespace App\Http\Controllers;

use App\Models\Permission;
use App\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use Spiritix\Html2Pdf\Converter;
use Spiritix\Html2Pdf\Input\UrlInput;
use Spiritix\Html2Pdf\Output\DownloadOutput;

class HomeController extends Controller
{
    //https://github.com/spiritix/php-chrome-html2pdf

    public function index()
    {

        $input = new UrlInput();
        $input->setUrl('https://laravel.com/');

        $converter = new Converter($input, new DownloadOutput());

        $converter->setOption('landscape', true);

        $converter->setOptions([
            'printBackground' => true,
            'displayHeaderFooter' => true,
            'headerTemplate' => '<p>I am a header</p>',
        ]);

        $converter->setLaunchOptions(
            (object)[
                'ignoreHTTPSErrors' => true,
                'headless' => "new",
                'executablePath' => 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
                'args' => [
                    '--no-sandbox',
                    '--disable-web-security',
                    '--font-render-hinting=none',
                    '--proxy-server="direct://"',
                    '--proxy-bypass-list=*',
                    '--media-cache-size=0',
                    '--disk-cache-size=0',
                    '--disable-application-cache',
                    '--disk-cache-dir=/dev/null',
                    '--media-cache-dir=/dev/null'
                ]
            ]
        );

        // print_r($converter);
        // die();

        $output = $converter->convert();



        $output->download('my.pdf');
    }

    public function dashboard()
    {
        $user = Auth::user();

        // Assign Role 

        // $role = Role::where('slug','admin')->first();
        // $user->roles()->attach($role);

        // check roles
        // dd($user->roles);

        // Has Role
        // dd($user->hasRole('l1'));

        // Assign Permission 

        //   $permission = Permission::where('slug','turn-on')->first();
        //   $user->permissions()->attach($permission);


        // check Permissions
        // dd($user->permissions);


        // dd($user->hasPermission('turn-on'));


        // dd($user->can('turn-off'));



        // if($user->hasRole('l1')){
        //     return view('dashboard');
        // }
        // elseif($user->hasRole('admin')){
        //     return view('dashboard');
        // }else{
        //     return "User Does Not Have Permission!";
        // }
        return view('dashboard');
    }
}
