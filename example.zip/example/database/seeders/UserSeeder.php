<?php

namespace Database\Seeders;

use App\Models\Permission;
use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //

        User::insert([
            ['name'=> "Admin" , 'email' => 'admin@gmail.com' , 'password' => bcrypt('password')], 
            ['name'=> "User1" , 'email' => 'user1@gmail.com' , 'password' => bcrypt('password')], 
            ['name'=> "User2" , 'email' => 'user2@gmail.com' , 'password' => bcrypt('password')], 
        ]);

       Role::insert([
            ['name'=> "Admin", 'slug'=> 'admin'],
            ['name'=> "L1", 'slug'=> 'l1'],
            ['name'=> "L2", 'slug'=> 'l2'],
        ]);

        Permission::insert([
            ['name'=> "turn on", 'slug'=> 'turn-on'],
            ['name'=> "turn off", 'slug'=> 'turn-off'],
        ]);
    }
}
